//
//  KindleApp.swift
//  Kindle
//
//  Created by Freddy Morales on 12/02/25.
//

import SwiftUI

@main
struct KindleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
